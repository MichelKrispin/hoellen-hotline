# Höllen-Hotline – Sprite Export

Dieses Paket enthält alle 34 bisherigen `PlaceholderName`-Assets als echte PNG-Sprites mit transparentem Hintergrund und exakt den Asset-Namen, die der aktuelle Phaser-Code erwartet.

## Integration

Das ZIP direkt im Repository-Root entpacken. Enthalten sind:

- `src/assets/source/placeholders/*.png` – alle 34 Sprites
- `src/assets/placeholders.ts` – Loader auf PNG statt SVG umgestellt
- `integration.patch` – dieselbe Loader-Änderung als kleiner Diff
- `_sprite_export/manifest.json` – Abmessungen und SHA-256-Prüfsummen
- `_sprite_export/sprite-contact-sheet.jpg` – Übersicht aller Sprites

Die alten SVG-Platzhalter dürfen im Ordner bleiben. Der enthaltene Loader lädt ausschließlich die neuen PNG-Dateien.

## Prüfen

```bash
npm ci
npm run lint
npm test
npm run build
VITE_BASE=/hoellen-hotline/ npm run build
```

Die Dateinamen entsprechen vollständig dem aktuellen `PlaceholderName`-Union-Type, darunter `hellscape-backdrop.png`, `telephone.png`, `archive-stack.png`, `lever-console.png`, `panel-metal.png`, `gauge-face.png`, `soul.png`, `smoke.png` usw.

Hinweis: Die vier `panel-*`-Assets bleiben mit dem bestehenden 32-px-NineSlice-Code kompatibel; die übrigen Assets werden wie bisher über `setDisplaySize()` skaliert.
